# This file was automatically created by FeynRules 2.4.55
# Mathematica version: 11.0.1 for Mac OS X x86 (64-bit) (September 21, 2016)
# Date: Thu 16 Mar 2017 17:39:37


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



R2GC_146_1 = Coupling(name = 'R2GC_146_1',
                      value = '-(complex(0,1)*G**2)/(16.*cmath.pi**2)',
                      order = {'QCD':2})

R2GC_147_2 = Coupling(name = 'R2GC_147_2',
                      value = '-(complex(0,1)*G**2*gTg)/(32.*cmath.pi**2*Lambda)',
                      order = {'DMT':1,'QCD':2})

R2GC_148_3 = Coupling(name = 'R2GC_148_3',
                      value = '(-185*G**3*gTg)/(512.*cmath.pi**2*Lambda)',
                      order = {'DMT':1,'QCD':3})

R2GC_150_4 = Coupling(name = 'R2GC_150_4',
                      value = '(G**3*gTg)/(128.*cmath.pi**2*Lambda)',
                      order = {'DMT':1,'QCD':3})

R2GC_151_5 = Coupling(name = 'R2GC_151_5',
                      value = '-(complex(0,1)*G**2*MT**2)/(8.*cmath.pi**2)',
                      order = {'QCD':2})

R2GC_152_6 = Coupling(name = 'R2GC_152_6',
                      value = '(complex(0,1)*G**2*gTq3*MT**2)/(16.*cmath.pi**2*Lambda)',
                      order = {'DMT':1,'QCD':2})

R2GC_153_7 = Coupling(name = 'R2GC_153_7',
                      value = '-(complex(0,1)*G**2*MT*yt)/(8.*cmath.pi**2*cmath.sqrt(2))',
                      order = {'QCD':2,'QED':1})

R2GC_154_8 = Coupling(name = 'R2GC_154_8',
                      value = '-(complex(0,1)*G**2*gTq3*MT*vev*yt)/(8.*cmath.pi**2*Lambda*cmath.sqrt(2))',
                      order = {'DMT':1,'QCD':2})

R2GC_155_9 = Coupling(name = 'R2GC_155_9',
                      value = '(complex(0,1)*G**2)/(12.*cmath.pi**2)',
                      order = {'QCD':2})

R2GC_156_10 = Coupling(name = 'R2GC_156_10',
                       value = '(ee*complex(0,1)*G**2)/(18.*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_157_11 = Coupling(name = 'R2GC_157_11',
                       value = '-(complex(0,1)*G**3)/(6.*cmath.pi**2)',
                       order = {'QCD':3})

R2GC_158_12 = Coupling(name = 'R2GC_158_12',
                       value = '-(complex(0,1)*G**2*gTg)/(36.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2})

R2GC_159_13 = Coupling(name = 'R2GC_159_13',
                       value = '-(ee*complex(0,1)*G**2*gTg)/(108.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_160_14 = Coupling(name = 'R2GC_160_14',
                       value = '(-5*complex(0,1)*G**3*gTg)/(144.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':3})

R2GC_161_15 = Coupling(name = 'R2GC_161_15',
                       value = '-(complex(0,1)*G**2*gTq)/(36.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2})

R2GC_162_16 = Coupling(name = 'R2GC_162_16',
                       value = '-(ee*complex(0,1)*G**2*gTq)/(108.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_163_17 = Coupling(name = 'R2GC_163_17',
                       value = '(43*complex(0,1)*G**3*gTq)/(576.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':3})

R2GC_164_18 = Coupling(name = 'R2GC_164_18',
                       value = '(cw*ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw)',
                       order = {'QCD':2,'QED':1})

R2GC_165_19 = Coupling(name = 'R2GC_165_19',
                       value = '-(cw*ee*complex(0,1)*G**2*gTg)/(18.*cmath.pi**2*Lambda*sw)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_166_20 = Coupling(name = 'R2GC_166_20',
                       value = '(cw*ee*complex(0,1)*G**2*gTq)/(36.*cmath.pi**2*Lambda*sw)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_167_21 = Coupling(name = 'R2GC_167_21',
                       value = '(ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_168_22 = Coupling(name = 'R2GC_168_22',
                       value = '-(ee*complex(0,1)*G**2*gTg*sw)/(54.*cw*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_169_23 = Coupling(name = 'R2GC_169_23',
                       value = '(ee*complex(0,1)*G**2*gTq*sw)/(108.*cw*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_171_24 = Coupling(name = 'R2GC_171_24',
                       value = '-(ee*complex(0,1)*G**2)/(9.*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_174_25 = Coupling(name = 'R2GC_174_25',
                       value = '(ee*complex(0,1)*G**2*gTg)/(54.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_177_26 = Coupling(name = 'R2GC_177_26',
                       value = '(ee*complex(0,1)*G**2*gTq)/(54.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_179_27 = Coupling(name = 'R2GC_179_27',
                       value = '-(cw*ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw)',
                       order = {'QCD':2,'QED':1})

R2GC_180_28 = Coupling(name = 'R2GC_180_28',
                       value = '(cw*ee*complex(0,1)*G**2*gTg)/(18.*cmath.pi**2*Lambda*sw)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_181_29 = Coupling(name = 'R2GC_181_29',
                       value = '-(cw*ee*complex(0,1)*G**2*gTq)/(36.*cmath.pi**2*Lambda*sw)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_218_30 = Coupling(name = 'R2GC_218_30',
                       value = '-(complex(0,1)*G**2*gTq3)/(36.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2})

R2GC_219_31 = Coupling(name = 'R2GC_219_31',
                       value = '(ee*complex(0,1)*G**2*gTq3)/(54.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_220_32 = Coupling(name = 'R2GC_220_32',
                       value = '(43*complex(0,1)*G**3*gTq3)/(576.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':3})

R2GC_221_33 = Coupling(name = 'R2GC_221_33',
                       value = '(complex(0,1)*G**2*gTg*MT)/(24.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2})

R2GC_222_34 = Coupling(name = 'R2GC_222_34',
                       value = '(complex(0,1)*G**2*gTq3*MT)/(24.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2})

R2GC_224_35 = Coupling(name = 'R2GC_224_35',
                       value = '-(cw*ee*complex(0,1)*G**2*gTq3)/(36.*cmath.pi**2*Lambda*sw)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_226_36 = Coupling(name = 'R2GC_226_36',
                       value = '(ee*complex(0,1)*G**2*gTq3*sw)/(108.*cw*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_242_37 = Coupling(name = 'R2GC_242_37',
                       value = '(ee*complex(0,1)*G**2*gTg)/(9.*cmath.pi**2*Lambda*sw*cmath.sqrt(2))',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_243_38 = Coupling(name = 'R2GC_243_38',
                       value = '-(ee*complex(0,1)*G**2*gTq)/(18.*cmath.pi**2*Lambda*sw*cmath.sqrt(2))',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_245_39 = Coupling(name = 'R2GC_245_39',
                       value = '-(ee*complex(0,1)*G**2*gTq)/(36.*cmath.pi**2*Lambda*sw*cmath.sqrt(2))',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_246_40 = Coupling(name = 'R2GC_246_40',
                       value = '-(ee*complex(0,1)*G**2*gTq3)/(36.*cmath.pi**2*Lambda*sw*cmath.sqrt(2))',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_249_41 = Coupling(name = 'R2GC_249_41',
                       value = '(complex(0,1)*G**2)/(48.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_250_42 = Coupling(name = 'R2GC_250_42',
                       value = '(ee**2*complex(0,1)*G**2)/(216.*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_250_43 = Coupling(name = 'R2GC_250_43',
                       value = '(ee**2*complex(0,1)*G**2)/(54.*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_251_44 = Coupling(name = 'R2GC_251_44',
                       value = '-(ee*complex(0,1)*G**3)/(144.*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

R2GC_251_45 = Coupling(name = 'R2GC_251_45',
                       value = '(ee*complex(0,1)*G**3)/(72.*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

R2GC_252_46 = Coupling(name = 'R2GC_252_46',
                       value = '-(complex(0,1)*G**2*gTq)/(48.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2})

R2GC_252_47 = Coupling(name = 'R2GC_252_47',
                       value = '-(complex(0,1)*G**2*gTq3)/(48.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2})

R2GC_253_48 = Coupling(name = 'R2GC_253_48',
                       value = '(-5*G**3*gTq)/(128.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':3})

R2GC_253_49 = Coupling(name = 'R2GC_253_49',
                       value = '(-5*G**3*gTq3)/(128.*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':3})

R2GC_254_50 = Coupling(name = 'R2GC_254_50',
                       value = '-(cw*ee*G**2)/(48.*cmath.pi**2*sw) - (ee*G**2*sw)/(48.*cw*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_254_51 = Coupling(name = 'R2GC_254_51',
                       value = '(cw*ee*G**2)/(48.*cmath.pi**2*sw) + (ee*G**2*sw)/(48.*cw*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_255_52 = Coupling(name = 'R2GC_255_52',
                       value = '(cw*ee**2*complex(0,1)*G**2)/(288.*cmath.pi**2*sw) - (ee**2*complex(0,1)*G**2*sw)/(864.*cw*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_255_53 = Coupling(name = 'R2GC_255_53',
                       value = '(cw*ee**2*complex(0,1)*G**2)/(144.*cmath.pi**2*sw) - (5*ee**2*complex(0,1)*G**2*sw)/(432.*cw*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_256_54 = Coupling(name = 'R2GC_256_54',
                       value = '-(cw*ee*complex(0,1)*G**3)/(192.*cmath.pi**2*sw) + (ee*complex(0,1)*G**3*sw)/(576.*cw*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

R2GC_256_55 = Coupling(name = 'R2GC_256_55',
                       value = '(cw*ee*complex(0,1)*G**3)/(192.*cmath.pi**2*sw) - (5*ee*complex(0,1)*G**3*sw)/(576.*cw*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

R2GC_257_56 = Coupling(name = 'R2GC_257_56',
                       value = '(3*cw*ee*complex(0,1)*G**3)/(64.*cmath.pi**2*sw) + (3*ee*complex(0,1)*G**3*sw)/(64.*cw*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

R2GC_257_57 = Coupling(name = 'R2GC_257_57',
                       value = '(-3*cw*ee*complex(0,1)*G**3)/(64.*cmath.pi**2*sw) - (3*ee*complex(0,1)*G**3*sw)/(64.*cw*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

R2GC_258_58 = Coupling(name = 'R2GC_258_58',
                       value = '(cw*ee*G**2*gTq)/(192.*cmath.pi**2*Lambda*sw) + (ee*G**2*gTq*sw)/(192.*cw*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_258_59 = Coupling(name = 'R2GC_258_59',
                       value = '-(cw*ee*G**2*gTq)/(192.*cmath.pi**2*Lambda*sw) - (ee*G**2*gTq*sw)/(192.*cw*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_258_60 = Coupling(name = 'R2GC_258_60',
                       value = '-(cw*ee*G**2*gTq3)/(192.*cmath.pi**2*Lambda*sw) - (ee*G**2*gTq3*sw)/(192.*cw*cmath.pi**2*Lambda)',
                       order = {'DMT':1,'QCD':2,'QED':1})

R2GC_259_61 = Coupling(name = 'R2GC_259_61',
                       value = '(ee**2*complex(0,1)*G**2)/(288.*cmath.pi**2) + (cw**2*ee**2*complex(0,1)*G**2)/(192.*cmath.pi**2*sw**2) + (5*ee**2*complex(0,1)*G**2*sw**2)/(1728.*cw**2*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_259_62 = Coupling(name = 'R2GC_259_62',
                       value = '-(ee**2*complex(0,1)*G**2)/(288.*cmath.pi**2) + (cw**2*ee**2*complex(0,1)*G**2)/(192.*cmath.pi**2*sw**2) + (17*ee**2*complex(0,1)*G**2*sw**2)/(1728.*cw**2*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_260_63 = Coupling(name = 'R2GC_260_63',
                       value = '(ee**2*complex(0,1)*G**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'QCD':2,'QED':2})

R2GC_348_64 = Coupling(name = 'R2GC_348_64',
                       value = '-G**4/(192.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_348_65 = Coupling(name = 'R2GC_348_65',
                       value = 'G**4/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_349_66 = Coupling(name = 'R2GC_349_66',
                       value = '-(complex(0,1)*G**4)/(192.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_349_67 = Coupling(name = 'R2GC_349_67',
                       value = '(complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_350_68 = Coupling(name = 'R2GC_350_68',
                       value = '(complex(0,1)*G**4)/(192.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_350_69 = Coupling(name = 'R2GC_350_69',
                       value = '-(complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_351_70 = Coupling(name = 'R2GC_351_70',
                       value = '-(complex(0,1)*G**4)/(48.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_352_71 = Coupling(name = 'R2GC_352_71',
                       value = '(complex(0,1)*G**4)/(288.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_352_72 = Coupling(name = 'R2GC_352_72',
                       value = '-(complex(0,1)*G**4)/(32.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_360_73 = Coupling(name = 'R2GC_360_73',
                       value = '(complex(0,1)*G**2*gTq3*vev*yt)/(3.*cmath.pi**2*Lambda*cmath.sqrt(2))',
                       order = {'DMT':1,'QCD':2})

R2GC_362_74 = Coupling(name = 'R2GC_362_74',
                       value = '-(ee*complex(0,1)*G**2)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                       order = {'QCD':2,'QED':1})

R2GC_366_75 = Coupling(name = 'R2GC_366_75',
                       value = 'G**3/(24.*cmath.pi**2)',
                       order = {'QCD':3})

R2GC_366_76 = Coupling(name = 'R2GC_366_76',
                       value = '(11*G**3)/(64.*cmath.pi**2)',
                       order = {'QCD':3})

R2GC_367_77 = Coupling(name = 'R2GC_367_77',
                       value = '(11*complex(0,1)*G**4)/(192.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_367_78 = Coupling(name = 'R2GC_367_78',
                       value = '(15*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_368_79 = Coupling(name = 'R2GC_368_79',
                       value = '(complex(0,1)*G**4)/(16.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_368_80 = Coupling(name = 'R2GC_368_80',
                       value = '(7*complex(0,1)*G**4)/(32.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_369_81 = Coupling(name = 'R2GC_369_81',
                       value = '(-3*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_369_82 = Coupling(name = 'R2GC_369_82',
                       value = '(-17*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_370_83 = Coupling(name = 'R2GC_370_83',
                       value = '-(complex(0,1)*G**4)/(16.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_370_84 = Coupling(name = 'R2GC_370_84',
                       value = '(-7*complex(0,1)*G**4)/(32.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_379_85 = Coupling(name = 'R2GC_379_85',
                       value = '(complex(0,1)*G**2*MT)/(6.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_386_86 = Coupling(name = 'R2GC_386_86',
                       value = '(G**2*yt)/(3.*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_387_87 = Coupling(name = 'R2GC_387_87',
                       value = '-(G**2*yt)/(3.*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_388_88 = Coupling(name = 'R2GC_388_88',
                       value = '(G**2*yt)/(3.*cmath.pi**2*cmath.sqrt(2))',
                       order = {'QCD':2,'QED':1})

R2GC_389_89 = Coupling(name = 'R2GC_389_89',
                       value = '(complex(0,1)*G**2*yt)/(3.*cmath.pi**2*cmath.sqrt(2))',
                       order = {'QCD':2,'QED':1})

UVGC_261_1 = Coupling(name = 'UVGC_261_1',
                      value = {-1:'(complex(0,1)*G**2*gTg)/(32.*cmath.pi**2*Lambda)'},
                      order = {'DMT':1,'QCD':2})

UVGC_262_2 = Coupling(name = 'UVGC_262_2',
                      value = {-1:'-(complex(0,1)*G**2*gTg)/(32.*cmath.pi**2*Lambda)'},
                      order = {'DMT':1,'QCD':2})

UVGC_263_3 = Coupling(name = 'UVGC_263_3',
                      value = {-1:'-(complex(0,1)*G**2)/(12.*cmath.pi**2)'},
                      order = {'QCD':2})

UVGC_264_4 = Coupling(name = 'UVGC_264_4',
                      value = {-1:'(ee*complex(0,1)*G**2)/(36.*cmath.pi**2)'},
                      order = {'QCD':2,'QED':1})

UVGC_265_5 = Coupling(name = 'UVGC_265_5',
                      value = {-1:'(-13*complex(0,1)*G**3)/(48.*cmath.pi**2)'},
                      order = {'QCD':3})

UVGC_266_6 = Coupling(name = 'UVGC_266_6',
                      value = {-1:'-(complex(0,1)*G**2*gTg)/(36.*cmath.pi**2*Lambda)'},
                      order = {'DMT':1,'QCD':2})

UVGC_267_7 = Coupling(name = 'UVGC_267_7',
                      value = {-1:'-(ee*complex(0,1)*G**2*gTg)/(108.*cmath.pi**2*Lambda)'},
                      order = {'DMT':1,'QCD':2,'QED':1})

UVGC_268_8 = Coupling(name = 'UVGC_268_8',
                      value = {-1:'(complex(0,1)*G**3*gTg)/(36.*cmath.pi**2*Lambda)'},
                      order = {'DMT':1,'QCD':3})

UVGC_269_9 = Coupling(name = 'UVGC_269_9',
                      value = {-1:'-(complex(0,1)*G**2*gTq)/(72.*cmath.pi**2*Lambda)'},
                      order = {'DMT':1,'QCD':2})

UVGC_270_10 = Coupling(name = 'UVGC_270_10',
                       value = {-1:'-(ee*complex(0,1)*G**2*gTq)/(216.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_271_11 = Coupling(name = 'UVGC_271_11',
                       value = {-1:'(31*complex(0,1)*G**3*gTq)/(288.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':3})

UVGC_272_12 = Coupling(name = 'UVGC_272_12',
                       value = {-1:'-(cw*ee*complex(0,1)*G**2*gTg)/(72.*cmath.pi**2*Lambda*sw)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_273_13 = Coupling(name = 'UVGC_273_13',
                       value = {-1:'-(cw*ee*complex(0,1)*G**2*gTq)/(36.*cmath.pi**2*Lambda*sw)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_274_14 = Coupling(name = 'UVGC_274_14',
                       value = {-1:'-(ee*complex(0,1)*G**2*gTg*sw)/(216.*cw*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_275_15 = Coupling(name = 'UVGC_275_15',
                       value = {-1:'-(ee*complex(0,1)*G**2*gTq*sw)/(108.*cw*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_277_16 = Coupling(name = 'UVGC_277_16',
                       value = {-1:'-(ee*complex(0,1)*G**2)/(18.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_280_17 = Coupling(name = 'UVGC_280_17',
                       value = {-1:'(ee*complex(0,1)*G**2*gTg)/(54.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_283_18 = Coupling(name = 'UVGC_283_18',
                       value = {-1:'(ee*complex(0,1)*G**2*gTq)/(108.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_285_19 = Coupling(name = 'UVGC_285_19',
                       value = {-1:'(cw*ee*complex(0,1)*G**2*gTg)/(72.*cmath.pi**2*Lambda*sw)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_286_20 = Coupling(name = 'UVGC_286_20',
                       value = {-1:'(cw*ee*complex(0,1)*G**2*gTq)/(36.*cmath.pi**2*Lambda*sw)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_318_21 = Coupling(name = 'UVGC_318_21',
                       value = {-1:'-(complex(0,1)*G**2*gTq3)/(72.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2})

UVGC_319_22 = Coupling(name = 'UVGC_319_22',
                       value = {-1:'(ee*complex(0,1)*G**2*gTq3)/(108.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_320_23 = Coupling(name = 'UVGC_320_23',
                       value = {-1:'(31*complex(0,1)*G**3*gTq3)/(288.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':3})

UVGC_321_24 = Coupling(name = 'UVGC_321_24',
                       value = {-1:'(complex(0,1)*G**2*gTg*MT)/(12.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2})

UVGC_323_25 = Coupling(name = 'UVGC_323_25',
                       value = {-1:'-(cw*ee*complex(0,1)*G**2*gTq3)/(72.*cmath.pi**2*Lambda*sw)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_325_26 = Coupling(name = 'UVGC_325_26',
                       value = {-1:'(ee*complex(0,1)*G**2*gTq3*sw)/(216.*cw*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_326_27 = Coupling(name = 'UVGC_326_27',
                       value = {0:'( (complex(0,1)*G**2*gTq3*vev*yt)/(3.*cmath.pi**2*Lambda*cmath.sqrt(2)) if MT else 0 )'},
                       order = {'DMT':1,'QCD':2})

UVGC_340_28 = Coupling(name = 'UVGC_340_28',
                       value = {-1:'(ee*complex(0,1)*G**2*gTg)/(36.*cmath.pi**2*Lambda*sw*cmath.sqrt(2))'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_341_29 = Coupling(name = 'UVGC_341_29',
                       value = {-1:'-(ee*complex(0,1)*G**2*gTq)/(36.*cmath.pi**2*Lambda*sw*cmath.sqrt(2))'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_343_30 = Coupling(name = 'UVGC_343_30',
                       value = {-1:'-(ee*complex(0,1)*G**2*gTq)/(72.*cmath.pi**2*Lambda*sw*cmath.sqrt(2))'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_344_31 = Coupling(name = 'UVGC_344_31',
                       value = {-1:'-(ee*complex(0,1)*G**2*gTq3)/(72.*cmath.pi**2*Lambda*sw*cmath.sqrt(2))'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_347_32 = Coupling(name = 'UVGC_347_32',
                       value = {-1:'(3*complex(0,1)*G**2)/(64.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_347_33 = Coupling(name = 'UVGC_347_33',
                       value = {-1:'(-3*complex(0,1)*G**2)/(64.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_348_34 = Coupling(name = 'UVGC_348_34',
                       value = {-1:'(3*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_348_35 = Coupling(name = 'UVGC_348_35',
                       value = {-1:'(-3*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_349_36 = Coupling(name = 'UVGC_349_36',
                       value = {-1:'(3*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_349_37 = Coupling(name = 'UVGC_349_37',
                       value = {-1:'(-3*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_351_38 = Coupling(name = 'UVGC_351_38',
                       value = {-1:'-(complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_351_39 = Coupling(name = 'UVGC_351_39',
                       value = {-1:'(complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_352_40 = Coupling(name = 'UVGC_352_40',
                       value = {-1:'(-3*complex(0,1)*G**4)/(256.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_352_41 = Coupling(name = 'UVGC_352_41',
                       value = {-1:'(3*complex(0,1)*G**4)/(256.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_353_42 = Coupling(name = 'UVGC_353_42',
                       value = {-1:'(complex(0,1)*G**3)/(48.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_353_43 = Coupling(name = 'UVGC_353_43',
                       value = {-1:'(-19*complex(0,1)*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_353_44 = Coupling(name = 'UVGC_353_44',
                       value = {-1:'-(complex(0,1)*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_353_45 = Coupling(name = 'UVGC_353_45',
                       value = {-1:'( 0 if MT else (complex(0,1)*G**3)/(48.*cmath.pi**2) )'},
                       order = {'QCD':3})

UVGC_354_46 = Coupling(name = 'UVGC_354_46',
                       value = {-1:'(complex(0,1)*G**2*gTq)/(24.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2})

UVGC_354_47 = Coupling(name = 'UVGC_354_47',
                       value = {-1:'(complex(0,1)*G**2*gTq3)/(24.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2})

UVGC_355_48 = Coupling(name = 'UVGC_355_48',
                       value = {-1:'(complex(0,1)*G**3*gTq)/(48.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':3})

UVGC_355_49 = Coupling(name = 'UVGC_355_49',
                       value = {-1:'(-19*complex(0,1)*G**3*gTq)/(128.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':3})

UVGC_355_50 = Coupling(name = 'UVGC_355_50',
                       value = {-1:'-(complex(0,1)*G**3*gTq)/(128.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':3})

UVGC_355_51 = Coupling(name = 'UVGC_355_51',
                       value = {-1:'( 0 if MT else (complex(0,1)*G**3*gTq)/(48.*cmath.pi**2*Lambda) )'},
                       order = {'DMT':1,'QCD':3})

UVGC_356_52 = Coupling(name = 'UVGC_356_52',
                       value = {-1:'(cw*ee*G**2*gTq)/(64.*cmath.pi**2*Lambda*sw) + (ee*G**2*gTq*sw)/(64.*cw*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_356_53 = Coupling(name = 'UVGC_356_53',
                       value = {-1:'-(cw*ee*G**2*gTq)/(64.*cmath.pi**2*Lambda*sw) - (ee*G**2*gTq*sw)/(64.*cw*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_356_54 = Coupling(name = 'UVGC_356_54',
                       value = {-1:'-(cw*ee*G**2*gTq3)/(64.*cmath.pi**2*Lambda*sw) - (ee*G**2*gTq3*sw)/(64.*cw*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_357_55 = Coupling(name = 'UVGC_357_55',
                       value = {-1:'(ee*complex(0,1)*G**2*gTq)/(24.*cmath.pi**2*Lambda*sw*cmath.sqrt(2))'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_360_56 = Coupling(name = 'UVGC_360_56',
                       value = {-1:'( (complex(0,1)*G**2*gTq3*vev*yt)/(6.*cmath.pi**2*Lambda*cmath.sqrt(2)) if MT else -(complex(0,1)*G**2*gTq3*vev*yt)/(12.*cmath.pi**2*Lambda*cmath.sqrt(2)) ) + (complex(0,1)*G**2*gTq3*vev*yt)/(3.*cmath.pi**2*Lambda*cmath.sqrt(2))',0:'( 0 if MT else (complex(0,1)*G**2*gTq3*vev*yt)/(12.*cmath.pi**2*Lambda*cmath.sqrt(2)) ) - (complex(0,1)*G**2*gTq3*vev*yt)/(12.*cmath.pi**2*Lambda*cmath.sqrt(2))'},
                       order = {'DMT':1,'QCD':2})

UVGC_362_57 = Coupling(name = 'UVGC_362_57',
                       value = {-1:'(ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_362_58 = Coupling(name = 'UVGC_362_58',
                       value = {-1:'-(ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_364_59 = Coupling(name = 'UVGC_364_59',
                       value = {0:'( -(complex(0,1)*G**2*gTq3*vev*yt*reglog(MT**2/MU_R**2))/(4.*cmath.pi**2*Lambda*cmath.sqrt(2)) if MT else 0 )'},
                       order = {'DMT':1,'QCD':2})

UVGC_365_60 = Coupling(name = 'UVGC_365_60',
                       value = {-1:'( 0 if MT else (complex(0,1)*G**2)/(24.*cmath.pi**2) ) - (complex(0,1)*G**2)/(24.*cmath.pi**2)',0:'( (complex(0,1)*G**2*reglog(MT**2/MU_R**2))/(24.*cmath.pi**2) if MT else 0 )'},
                       order = {'QCD':2})

UVGC_366_61 = Coupling(name = 'UVGC_366_61',
                       value = {-1:'-G**3/(48.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_366_62 = Coupling(name = 'UVGC_366_62',
                       value = {-1:'(21*G**3)/(64.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_366_63 = Coupling(name = 'UVGC_366_63',
                       value = {-1:'G**3/(64.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_366_64 = Coupling(name = 'UVGC_366_64',
                       value = {-1:'( 0 if MT else -G**3/(16.*cmath.pi**2) ) + G**3/(24.*cmath.pi**2)',0:'( -(G**3*reglog(MT**2/MU_R**2))/(24.*cmath.pi**2) if MT else 0 )'},
                       order = {'QCD':3})

UVGC_367_65 = Coupling(name = 'UVGC_367_65',
                       value = {-1:'-(complex(0,1)*G**4)/(24.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_367_66 = Coupling(name = 'UVGC_367_66',
                       value = {-1:'(335*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_367_67 = Coupling(name = 'UVGC_367_67',
                       value = {-1:'(17*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_367_68 = Coupling(name = 'UVGC_367_68',
                       value = {-1:'( 0 if MT else -(complex(0,1)*G**4)/(12.*cmath.pi**2) ) + (complex(0,1)*G**4)/(24.*cmath.pi**2)',0:'( -(complex(0,1)*G**4*reglog(MT**2/MU_R**2))/(24.*cmath.pi**2) if MT else 0 )'},
                       order = {'QCD':4})

UVGC_368_69 = Coupling(name = 'UVGC_368_69',
                       value = {-1:'(83*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_368_70 = Coupling(name = 'UVGC_368_70',
                       value = {-1:'(5*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_369_71 = Coupling(name = 'UVGC_369_71',
                       value = {-1:'(complex(0,1)*G**4)/(24.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_369_72 = Coupling(name = 'UVGC_369_72',
                       value = {-1:'(-341*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_369_73 = Coupling(name = 'UVGC_369_73',
                       value = {-1:'(-11*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_369_74 = Coupling(name = 'UVGC_369_74',
                       value = {-1:'( 0 if MT else (complex(0,1)*G**4)/(12.*cmath.pi**2) ) - (complex(0,1)*G**4)/(24.*cmath.pi**2)',0:'( (complex(0,1)*G**4*reglog(MT**2/MU_R**2))/(24.*cmath.pi**2) if MT else 0 )'},
                       order = {'QCD':4})

UVGC_370_75 = Coupling(name = 'UVGC_370_75',
                       value = {-1:'(-83*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_370_76 = Coupling(name = 'UVGC_370_76',
                       value = {-1:'(-5*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_371_77 = Coupling(name = 'UVGC_371_77',
                       value = {-1:'-(complex(0,1)*G**2*gTg)/(24.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2})

UVGC_371_78 = Coupling(name = 'UVGC_371_78',
                       value = {-1:'( 0 if MT else -(complex(0,1)*G**2*gTg)/(24.*cmath.pi**2*Lambda) )',0:'( -(complex(0,1)*G**2*gTg*reglog(MT**2/MU_R**2))/(24.*cmath.pi**2*Lambda) if MT else 0 )'},
                       order = {'DMT':1,'QCD':2})

UVGC_372_79 = Coupling(name = 'UVGC_372_79',
                       value = {-1:'(G**3*gTg)/(16.*cmath.pi**2*Lambda) - (G**3*gTq)/(24.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':3})

UVGC_372_80 = Coupling(name = 'UVGC_372_80',
                       value = {-1:'(-21*G**3*gTg)/(64.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':3})

UVGC_372_81 = Coupling(name = 'UVGC_372_81',
                       value = {-1:'-(G**3*gTg)/(64.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':3})

UVGC_372_82 = Coupling(name = 'UVGC_372_82',
                       value = {-1:'( 0 if MT else (G**3*gTg)/(16.*cmath.pi**2*Lambda) ) - (G**3*gTq3)/(24.*cmath.pi**2*Lambda)',0:'( (G**3*gTg*reglog(MT**2/MU_R**2))/(24.*cmath.pi**2*Lambda) if MT else 0 )'},
                       order = {'DMT':1,'QCD':3})

UVGC_373_83 = Coupling(name = 'UVGC_373_83',
                       value = {-1:'( (complex(0,1)*G**2)/(6.*cmath.pi**2) if MT else -(complex(0,1)*G**2)/(12.*cmath.pi**2) ) + (complex(0,1)*G**2)/(12.*cmath.pi**2)',0:'( (5*complex(0,1)*G**2)/(12.*cmath.pi**2) - (complex(0,1)*G**2*reglog(MT**2/MU_R**2))/(4.*cmath.pi**2) if MT else (complex(0,1)*G**2)/(12.*cmath.pi**2) ) - (complex(0,1)*G**2)/(12.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_374_84 = Coupling(name = 'UVGC_374_84',
                       value = {-1:'( -(ee*complex(0,1)*G**2)/(9.*cmath.pi**2) if MT else (ee*complex(0,1)*G**2)/(18.*cmath.pi**2) )',0:'( (-5*ee*complex(0,1)*G**2)/(18.*cmath.pi**2) + (ee*complex(0,1)*G**2*reglog(MT**2/MU_R**2))/(6.*cmath.pi**2) if MT else -(ee*complex(0,1)*G**2)/(18.*cmath.pi**2) ) + (ee*complex(0,1)*G**2)/(18.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_375_85 = Coupling(name = 'UVGC_375_85',
                       value = {-1:'( -(complex(0,1)*G**3)/(6.*cmath.pi**2) if MT else (complex(0,1)*G**3)/(12.*cmath.pi**2) )',0:'( (-5*complex(0,1)*G**3)/(12.*cmath.pi**2) + (complex(0,1)*G**3*reglog(MT**2/MU_R**2))/(4.*cmath.pi**2) if MT else -(complex(0,1)*G**3)/(12.*cmath.pi**2) ) + (complex(0,1)*G**3)/(12.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_376_86 = Coupling(name = 'UVGC_376_86',
                       value = {-1:'( -(complex(0,1)*G**2*gTq3)/(24.*cmath.pi**2*Lambda) if MT else (complex(0,1)*G**2*gTq3)/(48.*cmath.pi**2*Lambda) )',0:'( (-5*complex(0,1)*G**2*gTq3)/(48.*cmath.pi**2*Lambda) + (complex(0,1)*G**2*gTq3*reglog(MT**2/MU_R**2))/(16.*cmath.pi**2*Lambda) if MT else -(complex(0,1)*G**2*gTq3)/(48.*cmath.pi**2*Lambda) ) + (complex(0,1)*G**2*gTq3)/(48.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2})

UVGC_377_87 = Coupling(name = 'UVGC_377_87',
                       value = {-1:'( -(ee*complex(0,1)*G**2*gTq3)/(9.*cmath.pi**2*Lambda) if MT else (ee*complex(0,1)*G**2*gTq3)/(18.*cmath.pi**2*Lambda) )',0:'( (-5*ee*complex(0,1)*G**2*gTq3)/(18.*cmath.pi**2*Lambda) + (ee*complex(0,1)*G**2*gTq3*reglog(MT**2/MU_R**2))/(6.*cmath.pi**2*Lambda) if MT else -(ee*complex(0,1)*G**2*gTq3)/(18.*cmath.pi**2*Lambda) ) + (ee*complex(0,1)*G**2*gTq3)/(18.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_378_88 = Coupling(name = 'UVGC_378_88',
                       value = {-1:'(complex(0,1)*G**3*gTq3)/(48.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':3})

UVGC_378_89 = Coupling(name = 'UVGC_378_89',
                       value = {-1:'(-19*complex(0,1)*G**3*gTq3)/(128.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':3})

UVGC_378_90 = Coupling(name = 'UVGC_378_90',
                       value = {-1:'-(complex(0,1)*G**3*gTq3)/(128.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':3})

UVGC_378_91 = Coupling(name = 'UVGC_378_91',
                       value = {-1:'( 0 if MT else (complex(0,1)*G**3*gTq3)/(48.*cmath.pi**2*Lambda) )'},
                       order = {'DMT':1,'QCD':3})

UVGC_378_92 = Coupling(name = 'UVGC_378_92',
                       value = {-1:'( -(complex(0,1)*G**3*gTq3)/(6.*cmath.pi**2*Lambda) if MT else (complex(0,1)*G**3*gTq3)/(12.*cmath.pi**2*Lambda) )',0:'( (-5*complex(0,1)*G**3*gTq3)/(12.*cmath.pi**2*Lambda) + (complex(0,1)*G**3*gTq3*reglog(MT**2/MU_R**2))/(4.*cmath.pi**2*Lambda) if MT else -(complex(0,1)*G**3*gTq3)/(12.*cmath.pi**2*Lambda) ) + (complex(0,1)*G**3*gTq3)/(12.*cmath.pi**2*Lambda)'},
                       order = {'DMT':1,'QCD':3})

UVGC_379_93 = Coupling(name = 'UVGC_379_93',
                       value = {-1:'( (complex(0,1)*G**2*MT)/(6.*cmath.pi**2) if MT else -(complex(0,1)*G**2*MT)/(12.*cmath.pi**2) ) + (complex(0,1)*G**2*MT)/(3.*cmath.pi**2)',0:'( (3*complex(0,1)*G**2*MT)/(4.*cmath.pi**2) - (complex(0,1)*G**2*MT*reglog(MT**2/MU_R**2))/(2.*cmath.pi**2) if MT else (complex(0,1)*G**2*MT)/(12.*cmath.pi**2) ) - (complex(0,1)*G**2*MT)/(12.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_380_94 = Coupling(name = 'UVGC_380_94',
                       value = {-1:'( -(ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw*cmath.sqrt(2)) if MT else (ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) )',0:'( (-5*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*reglog(MT**2/MU_R**2))/(8.*cmath.pi**2*sw*cmath.sqrt(2)) if MT else -(ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) ) + (ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_381_95 = Coupling(name = 'UVGC_381_95',
                       value = {-1:'( -(cw*ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw) if MT else (cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw) ) - (cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw)',0:'( (-5*cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw) + (cw*ee*complex(0,1)*G**2*reglog(MT**2/MU_R**2))/(8.*cmath.pi**2*sw) if MT else -(cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw) ) + (cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw)'},
                       order = {'QCD':2,'QED':1})

UVGC_382_96 = Coupling(name = 'UVGC_382_96',
                       value = {-1:'(ee*complex(0,1)*G**2*gTq)/(48.*cmath.pi**2*Lambda*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*gTq3)/(48.*cmath.pi**2*Lambda*sw*cmath.sqrt(2))'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_382_97 = Coupling(name = 'UVGC_382_97',
                       value = {-1:'( -(ee*complex(0,1)*G**2*gTq)/(24.*cmath.pi**2*Lambda*sw*cmath.sqrt(2)) - (ee*complex(0,1)*G**2*gTq3)/(24.*cmath.pi**2*Lambda*sw*cmath.sqrt(2)) if MT else (ee*complex(0,1)*G**2*gTq)/(48.*cmath.pi**2*Lambda*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*gTq3)/(48.*cmath.pi**2*Lambda*sw*cmath.sqrt(2)) )',0:'( (-5*ee*complex(0,1)*G**2*gTq)/(48.*cmath.pi**2*Lambda*sw*cmath.sqrt(2)) - (5*ee*complex(0,1)*G**2*gTq3)/(48.*cmath.pi**2*Lambda*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*gTq*reglog(MT**2/MU_R**2))/(16.*cmath.pi**2*Lambda*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*gTq3*reglog(MT**2/MU_R**2))/(16.*cmath.pi**2*Lambda*sw*cmath.sqrt(2)) if MT else -(ee*complex(0,1)*G**2*gTq)/(48.*cmath.pi**2*Lambda*sw*cmath.sqrt(2)) - (ee*complex(0,1)*G**2*gTq3)/(48.*cmath.pi**2*Lambda*sw*cmath.sqrt(2)) ) + (ee*complex(0,1)*G**2*gTq)/(48.*cmath.pi**2*Lambda*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*gTq3)/(48.*cmath.pi**2*Lambda*sw*cmath.sqrt(2))'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_383_98 = Coupling(name = 'UVGC_383_98',
                       value = {-1:'( -(cw*ee*complex(0,1)*G**2*gTq3)/(12.*cmath.pi**2*Lambda*sw) if MT else (cw*ee*complex(0,1)*G**2*gTq3)/(24.*cmath.pi**2*Lambda*sw) )',0:'( (-5*cw*ee*complex(0,1)*G**2*gTq3)/(24.*cmath.pi**2*Lambda*sw) + (cw*ee*complex(0,1)*G**2*gTq3*reglog(MT**2/MU_R**2))/(8.*cmath.pi**2*Lambda*sw) if MT else -(cw*ee*complex(0,1)*G**2*gTq3)/(24.*cmath.pi**2*Lambda*sw) ) + (cw*ee*complex(0,1)*G**2*gTq3)/(24.*cmath.pi**2*Lambda*sw)'},
                       order = {'DMT':1,'QCD':2,'QED':1})

UVGC_384_99 = Coupling(name = 'UVGC_384_99',
                       value = {-1:'( (ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2) if MT else -(ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2) ) + (ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2)',0:'( (5*ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2) - (ee*complex(0,1)*G**2*sw*reglog(MT**2/MU_R**2))/(24.*cw*cmath.pi**2) if MT else (ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2) ) - (ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_385_100 = Coupling(name = 'UVGC_385_100',
                        value = {-1:'( (ee*complex(0,1)*G**2*gTq3*sw)/(36.*cw*cmath.pi**2*Lambda) if MT else -(ee*complex(0,1)*G**2*gTq3*sw)/(72.*cw*cmath.pi**2*Lambda) )',0:'( (5*ee*complex(0,1)*G**2*gTq3*sw)/(72.*cw*cmath.pi**2*Lambda) - (ee*complex(0,1)*G**2*gTq3*sw*reglog(MT**2/MU_R**2))/(24.*cw*cmath.pi**2*Lambda) if MT else (ee*complex(0,1)*G**2*gTq3*sw)/(72.*cw*cmath.pi**2*Lambda) ) - (ee*complex(0,1)*G**2*gTq3*sw)/(72.*cw*cmath.pi**2*Lambda)'},
                        order = {'DMT':1,'QCD':2,'QED':1})

UVGC_386_101 = Coupling(name = 'UVGC_386_101',
                        value = {-1:'-(G**2*yt)/(24.*cmath.pi**2)'},
                        order = {'QCD':2,'QED':1})

UVGC_386_102 = Coupling(name = 'UVGC_386_102',
                        value = {-1:'( (G**2*yt)/(12.*cmath.pi**2) if MT else -(G**2*yt)/(24.*cmath.pi**2) )',0:'( (13*G**2*yt)/(24.*cmath.pi**2) - (3*G**2*yt*reglog(MT**2/MU_R**2))/(8.*cmath.pi**2) if MT else (G**2*yt)/(24.*cmath.pi**2) ) - (G**2*yt)/(24.*cmath.pi**2)'},
                        order = {'QCD':2,'QED':1})

UVGC_386_103 = Coupling(name = 'UVGC_386_103',
                        value = {-1:'(G**2*yt)/(3.*cmath.pi**2)'},
                        order = {'QCD':2,'QED':1})

UVGC_387_104 = Coupling(name = 'UVGC_387_104',
                        value = {-1:'(G**2*yt)/(24.*cmath.pi**2)'},
                        order = {'QCD':2,'QED':1})

UVGC_387_105 = Coupling(name = 'UVGC_387_105',
                        value = {-1:'( -(G**2*yt)/(12.*cmath.pi**2) if MT else (G**2*yt)/(24.*cmath.pi**2) )',0:'( (-13*G**2*yt)/(24.*cmath.pi**2) + (3*G**2*yt*reglog(MT**2/MU_R**2))/(8.*cmath.pi**2) if MT else -(G**2*yt)/(24.*cmath.pi**2) ) + (G**2*yt)/(24.*cmath.pi**2)'},
                        order = {'QCD':2,'QED':1})

UVGC_387_106 = Coupling(name = 'UVGC_387_106',
                        value = {-1:'-(G**2*yt)/(3.*cmath.pi**2)'},
                        order = {'QCD':2,'QED':1})

UVGC_388_107 = Coupling(name = 'UVGC_388_107',
                        value = {-1:'( (G**2*yt)/(6.*cmath.pi**2*cmath.sqrt(2)) if MT else -(G**2*yt)/(12.*cmath.pi**2*cmath.sqrt(2)) ) + (G**2*yt)/(3.*cmath.pi**2*cmath.sqrt(2))',0:'( (3*G**2*yt)/(4.*cmath.pi**2*cmath.sqrt(2)) - (G**2*yt*reglog(MT**2/MU_R**2))/(2.*cmath.pi**2*cmath.sqrt(2)) if MT else (G**2*yt)/(12.*cmath.pi**2*cmath.sqrt(2)) ) - (G**2*yt)/(12.*cmath.pi**2*cmath.sqrt(2))'},
                        order = {'QCD':2,'QED':1})

UVGC_389_108 = Coupling(name = 'UVGC_389_108',
                        value = {-1:'( (complex(0,1)*G**2*yt)/(6.*cmath.pi**2*cmath.sqrt(2)) if MT else -(complex(0,1)*G**2*yt)/(12.*cmath.pi**2*cmath.sqrt(2)) ) + (complex(0,1)*G**2*yt)/(3.*cmath.pi**2*cmath.sqrt(2))',0:'( (3*complex(0,1)*G**2*yt)/(4.*cmath.pi**2*cmath.sqrt(2)) - (complex(0,1)*G**2*yt*reglog(MT**2/MU_R**2))/(2.*cmath.pi**2*cmath.sqrt(2)) if MT else (complex(0,1)*G**2*yt)/(12.*cmath.pi**2*cmath.sqrt(2)) ) - (complex(0,1)*G**2*yt)/(12.*cmath.pi**2*cmath.sqrt(2))'},
                        order = {'QCD':2,'QED':1})

