# This file was automatically created by FeynRules 2.4.55
# Mathematica version: 11.0.1 for Mac OS X x86 (64-bit) (September 21, 2016)
# Date: Thu 16 Mar 2017 17:39:37


from object_library import all_vertices, all_CTvertices, Vertex, CTVertex
import particles as P
import CT_couplings as C
import lorentz as L


V_1 = CTVertex(name = 'V_1',
               type = 'R2',
               particles = [ P.g, P.g, P.g ],
               color = [ 'f(1,2,3)' ],
               lorentz = [ L.VVV2 ],
               loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.t], [P.u] ], [ [P.g] ] ],
               couplings = {(0,0,0):C.R2GC_366_75,(0,0,1):C.R2GC_366_76})

V_2 = CTVertex(name = 'V_2',
               type = 'R2',
               particles = [ P.g, P.g, P.g, P.g ],
               color = [ 'd(-1,1,3)*d(-1,2,4)', 'd(-1,1,3)*f(-1,2,4)', 'd(-1,1,4)*d(-1,2,3)', 'd(-1,1,4)*f(-1,2,3)', 'd(-1,2,3)*f(-1,1,4)', 'd(-1,2,4)*f(-1,1,3)', 'f(-1,1,2)*f(-1,3,4)', 'f(-1,1,3)*f(-1,2,4)', 'f(-1,1,4)*f(-1,2,3)', 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
               lorentz = [ L.VVVV10, L.VVVV2, L.VVVV3, L.VVVV5 ],
               loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.t], [P.u] ], [ [P.g] ] ],
               couplings = {(2,1,0):C.R2GC_350_68,(2,1,1):C.R2GC_350_69,(0,1,0):C.R2GC_350_68,(0,1,1):C.R2GC_350_69,(4,1,0):C.R2GC_348_64,(4,1,1):C.R2GC_348_65,(3,1,0):C.R2GC_348_64,(3,1,1):C.R2GC_348_65,(8,1,0):C.R2GC_349_66,(8,1,1):C.R2GC_349_67,(7,1,0):C.R2GC_369_81,(7,1,1):C.R2GC_369_82,(6,1,0):C.R2GC_370_83,(6,1,1):C.R2GC_370_84,(5,1,0):C.R2GC_348_64,(5,1,1):C.R2GC_348_65,(1,1,0):C.R2GC_348_64,(1,1,1):C.R2GC_348_65,(11,0,0):C.R2GC_352_71,(11,0,1):C.R2GC_352_72,(10,0,0):C.R2GC_352_71,(10,0,1):C.R2GC_352_72,(9,0,1):C.R2GC_351_70,(2,2,0):C.R2GC_350_68,(2,2,1):C.R2GC_350_69,(0,2,0):C.R2GC_350_68,(0,2,1):C.R2GC_350_69,(6,2,0):C.R2GC_368_79,(6,2,1):C.R2GC_368_80,(4,2,0):C.R2GC_348_64,(4,2,1):C.R2GC_348_65,(3,2,0):C.R2GC_348_64,(3,2,1):C.R2GC_348_65,(8,2,0):C.R2GC_369_81,(8,2,1):C.R2GC_369_82,(5,2,0):C.R2GC_348_64,(5,2,1):C.R2GC_348_65,(1,2,0):C.R2GC_348_64,(1,2,1):C.R2GC_348_65,(7,2,0):C.R2GC_349_66,(7,2,1):C.R2GC_349_67,(2,3,0):C.R2GC_350_68,(2,3,1):C.R2GC_350_69,(0,3,0):C.R2GC_350_68,(0,3,1):C.R2GC_350_69,(4,3,0):C.R2GC_348_64,(4,3,1):C.R2GC_348_65,(3,3,0):C.R2GC_348_64,(3,3,1):C.R2GC_348_65,(8,3,0):C.R2GC_367_77,(8,3,1):C.R2GC_367_78,(7,3,0):C.R2GC_367_77,(7,3,1):C.R2GC_367_78,(5,3,0):C.R2GC_348_64,(5,3,1):C.R2GC_348_65,(1,3,0):C.R2GC_348_64,(1,3,1):C.R2GC_348_65})

V_3 = CTVertex(name = 'V_3',
               type = 'R2',
               particles = [ P.b__tilde__, P.t, P.G__minus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3 ],
               loop_particles = [ [ [P.b, P.g, P.t] ] ],
               couplings = {(0,0,0):C.R2GC_387_87})

V_4 = CTVertex(name = 'V_4',
               type = 'R2',
               particles = [ P.t__tilde__, P.t, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               loop_particles = [ [ [P.g, P.t] ] ],
               couplings = {(0,0,0):C.R2GC_388_88})

V_5 = CTVertex(name = 'V_5',
               type = 'R2',
               particles = [ P.t__tilde__, P.t, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               loop_particles = [ [ [P.g, P.t] ] ],
               couplings = {(0,0,0):C.R2GC_389_89})

V_6 = CTVertex(name = 'V_6',
               type = 'R2',
               particles = [ P.g, P.g, P.Y2 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.VVT1, L.VVT11, L.VVT3, L.VVT8, L.VVT9 ],
               loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ] ],
               couplings = {(0,4,0):C.R2GC_252_46,(0,4,3):C.R2GC_252_47,(0,1,1):C.R2GC_147_2,(0,2,3):C.R2GC_152_6,(0,3,2):C.R2GC_147_2,(0,0,3):C.R2GC_154_8})

V_7 = CTVertex(name = 'V_7',
               type = 'R2',
               particles = [ P.g, P.g, P.g, P.Y2 ],
               color = [ 'f(1,2,3)' ],
               lorentz = [ L.VVVT3, L.VVVT4, L.VVVT6 ],
               loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ] ],
               couplings = {(0,1,0):C.R2GC_253_48,(0,1,3):C.R2GC_253_49,(0,2,1):C.R2GC_148_3,(0,0,2):C.R2GC_150_4})

V_8 = CTVertex(name = 'V_8',
               type = 'R2',
               particles = [ P.t__tilde__, P.t, P.Y2 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFT12, L.FFT14, L.FFT5, L.FFT8, L.FFT9 ],
               loop_particles = [ [ [P.g, P.t] ] ],
               couplings = {(0,1,0):C.R2GC_158_12,(0,0,0):C.R2GC_218_30,(0,4,0):C.R2GC_221_33,(0,3,0):C.R2GC_222_34,(0,2,0):C.R2GC_360_73})

V_9 = CTVertex(name = 'V_9',
               type = 'R2',
               particles = [ P.t__tilde__, P.b, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS5 ],
               loop_particles = [ [ [P.b, P.g, P.t] ] ],
               couplings = {(0,0,0):C.R2GC_386_86})

V_10 = CTVertex(name = 'V_10',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFT17, L.FFT19 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,1,0):C.R2GC_158_12,(0,0,0):C.R2GC_161_15})

V_11 = CTVertex(name = 'V_11',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFT17, L.FFT19 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,1,0):C.R2GC_158_12,(0,0,0):C.R2GC_161_15})

V_12 = CTVertex(name = 'V_12',
                type = 'R2',
                particles = [ P.d__tilde__, P.d, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFT17, L.FFT19 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,1,0):C.R2GC_158_12,(0,0,0):C.R2GC_161_15})

V_13 = CTVertex(name = 'V_13',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFT17, L.FFT19 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,1,0):C.R2GC_158_12,(0,0,0):C.R2GC_161_15})

V_14 = CTVertex(name = 'V_14',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFT17, L.FFT19 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,1,0):C.R2GC_158_12,(0,0,0):C.R2GC_161_15})

V_15 = CTVertex(name = 'V_15',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.a, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT12, L.FFVT14 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_174_25,(0,1,0):C.R2GC_219_31})

V_16 = CTVertex(name = 'V_16',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.Z, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT29, L.FFVT31, L.FFVT5, L.FFVT9 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,3,0):C.R2GC_180_28,(0,2,0):C.R2GC_224_35,(0,1,0):C.R2GC_168_22,(0,0,0):C.R2GC_226_36})

V_17 = CTVertex(name = 'V_17',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.a, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT12, L.FFVT14 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_159_13,(0,1,0):C.R2GC_162_16})

V_18 = CTVertex(name = 'V_18',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.Z, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT20, L.FFVT22, L.FFVT5, L.FFVT9 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,3,0):C.R2GC_165_19,(0,2,0):C.R2GC_166_20,(0,0,0):C.R2GC_168_22,(0,1,0):C.R2GC_169_23})

V_19 = CTVertex(name = 'V_19',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.a, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT12, L.FFVT14 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_174_25,(0,1,0):C.R2GC_177_26})

V_20 = CTVertex(name = 'V_20',
                type = 'R2',
                particles = [ P.d__tilde__, P.d, P.a, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT12, L.FFVT14 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_159_13,(0,1,0):C.R2GC_162_16})

V_21 = CTVertex(name = 'V_21',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.Z, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT29, L.FFVT31, L.FFVT5, L.FFVT9 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,3,0):C.R2GC_180_28,(0,2,0):C.R2GC_181_29,(0,1,0):C.R2GC_168_22,(0,0,0):C.R2GC_169_23})

V_22 = CTVertex(name = 'V_22',
                type = 'R2',
                particles = [ P.d__tilde__, P.d, P.Z, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT20, L.FFVT22, L.FFVT5, L.FFVT9 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,3,0):C.R2GC_165_19,(0,2,0):C.R2GC_166_20,(0,0,0):C.R2GC_168_22,(0,1,0):C.R2GC_169_23})

V_23 = CTVertex(name = 'V_23',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.a, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT12, L.FFVT14 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_174_25,(0,1,0):C.R2GC_177_26})

V_24 = CTVertex(name = 'V_24',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.a, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT12, L.FFVT14 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_159_13,(0,1,0):C.R2GC_162_16})

V_25 = CTVertex(name = 'V_25',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.Z, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT29, L.FFVT31, L.FFVT5, L.FFVT9 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,3,0):C.R2GC_180_28,(0,2,0):C.R2GC_181_29,(0,1,0):C.R2GC_168_22,(0,0,0):C.R2GC_169_23})

V_26 = CTVertex(name = 'V_26',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.Z, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT20, L.FFVT22, L.FFVT5, L.FFVT9 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,3,0):C.R2GC_165_19,(0,2,0):C.R2GC_166_20,(0,0,0):C.R2GC_168_22,(0,1,0):C.R2GC_169_23})

V_27 = CTVertex(name = 'V_27',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.g, P.Y2 ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFVT16, L.FFVT18 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,1,0):C.R2GC_160_14,(0,0,0):C.R2GC_163_17})

V_28 = CTVertex(name = 'V_28',
                type = 'R2',
                particles = [ P.d__tilde__, P.d, P.g, P.Y2 ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFVT16, L.FFVT18 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,1,0):C.R2GC_160_14,(0,0,0):C.R2GC_163_17})

V_29 = CTVertex(name = 'V_29',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.g, P.Y2 ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFVT16, L.FFVT18 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,1,0):C.R2GC_160_14,(0,0,0):C.R2GC_163_17})

V_30 = CTVertex(name = 'V_30',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.g, P.Y2 ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFVT16, L.FFVT18 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,1,0):C.R2GC_160_14,(0,0,0):C.R2GC_163_17})

V_31 = CTVertex(name = 'V_31',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.g, P.Y2 ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFVT16, L.FFVT18 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,1,0):C.R2GC_160_14,(0,0,0):C.R2GC_163_17})

V_32 = CTVertex(name = 'V_32',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.g, P.Y2 ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFVT16, L.FFVT18 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,1,0):C.R2GC_160_14,(0,0,0):C.R2GC_220_32})

V_33 = CTVertex(name = 'V_33',
                type = 'R2',
                particles = [ P.d__tilde__, P.u, P.W__minus__, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT5, L.FFVT9 ],
                loop_particles = [ [ [P.d, P.g, P.u] ] ],
                couplings = {(0,1,0):C.R2GC_242_37,(0,0,0):C.R2GC_243_38})

V_34 = CTVertex(name = 'V_34',
                type = 'R2',
                particles = [ P.u__tilde__, P.d, P.W__plus__, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT5, L.FFVT9 ],
                loop_particles = [ [ [P.d, P.g, P.u] ] ],
                couplings = {(0,1,0):C.R2GC_242_37,(0,0,0):C.R2GC_243_38})

V_35 = CTVertex(name = 'V_35',
                type = 'R2',
                particles = [ P.s__tilde__, P.c, P.W__minus__, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT5, L.FFVT9 ],
                loop_particles = [ [ [P.c, P.g, P.s] ] ],
                couplings = {(0,1,0):C.R2GC_242_37,(0,0,0):C.R2GC_243_38})

V_36 = CTVertex(name = 'V_36',
                type = 'R2',
                particles = [ P.c__tilde__, P.s, P.W__plus__, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT5, L.FFVT9 ],
                loop_particles = [ [ [P.c, P.g, P.s] ] ],
                couplings = {(0,1,0):C.R2GC_242_37,(0,0,0):C.R2GC_243_38})

V_37 = CTVertex(name = 'V_37',
                type = 'R2',
                particles = [ P.t__tilde__, P.b, P.W__plus__, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT2, L.FFVT7, L.FFVT9 ],
                loop_particles = [ [ [P.b, P.g, P.t] ] ],
                couplings = {(0,2,0):C.R2GC_242_37,(0,0,0):C.R2GC_245_39,(0,1,0):C.R2GC_246_40})

V_38 = CTVertex(name = 'V_38',
                type = 'R2',
                particles = [ P.b__tilde__, P.t, P.W__minus__, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT2, L.FFVT7, L.FFVT9 ],
                loop_particles = [ [ [P.b, P.g, P.t] ] ],
                couplings = {(0,2,0):C.R2GC_242_37,(0,1,0):C.R2GC_245_39,(0,0,0):C.R2GC_246_40})

V_39 = CTVertex(name = 'V_39',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_171_24})

V_40 = CTVertex(name = 'V_40',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_171_24})

V_41 = CTVertex(name = 'V_41',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_171_24})

V_42 = CTVertex(name = 'V_42',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_156_10})

V_43 = CTVertex(name = 'V_43',
                type = 'R2',
                particles = [ P.d__tilde__, P.d, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_156_10})

V_44 = CTVertex(name = 'V_44',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_156_10})

V_45 = CTVertex(name = 'V_45',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_157_11})

V_46 = CTVertex(name = 'V_46',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_157_11})

V_47 = CTVertex(name = 'V_47',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_157_11})

V_48 = CTVertex(name = 'V_48',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_157_11})

V_49 = CTVertex(name = 'V_49',
                type = 'R2',
                particles = [ P.d__tilde__, P.d, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_157_11})

V_50 = CTVertex(name = 'V_50',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_157_11})

V_51 = CTVertex(name = 'V_51',
                type = 'R2',
                particles = [ P.s__tilde__, P.c, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                loop_particles = [ [ [P.c, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_362_74})

V_52 = CTVertex(name = 'V_52',
                type = 'R2',
                particles = [ P.b__tilde__, P.t, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                loop_particles = [ [ [P.b, P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_362_74})

V_53 = CTVertex(name = 'V_53',
                type = 'R2',
                particles = [ P.d__tilde__, P.u, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                loop_particles = [ [ [P.d, P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_362_74})

V_54 = CTVertex(name = 'V_54',
                type = 'R2',
                particles = [ P.t__tilde__, P.b, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                loop_particles = [ [ [P.b, P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_362_74})

V_55 = CTVertex(name = 'V_55',
                type = 'R2',
                particles = [ P.u__tilde__, P.d, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                loop_particles = [ [ [P.d, P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_362_74})

V_56 = CTVertex(name = 'V_56',
                type = 'R2',
                particles = [ P.c__tilde__, P.s, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2 ],
                loop_particles = [ [ [P.c, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_362_74})

V_57 = CTVertex(name = 'V_57',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2, L.FFV8 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_179_27,(0,1,0):C.R2GC_167_21})

V_58 = CTVertex(name = 'V_58',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2, L.FFV8 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_179_27,(0,1,0):C.R2GC_167_21})

V_59 = CTVertex(name = 'V_59',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2, L.FFV8 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_179_27,(0,1,0):C.R2GC_167_21})

V_60 = CTVertex(name = 'V_60',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2, L.FFV3 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_164_18,(0,1,0):C.R2GC_167_21})

V_61 = CTVertex(name = 'V_61',
                type = 'R2',
                particles = [ P.d__tilde__, P.d, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2, L.FFV3 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_164_18,(0,1,0):C.R2GC_167_21})

V_62 = CTVertex(name = 'V_62',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV2, L.FFV3 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_164_18,(0,1,0):C.R2GC_167_21})

V_63 = CTVertex(name = 'V_63',
                type = 'R2',
                particles = [ P.g, P.g ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.VV2, L.VV3, L.VV4 ],
                loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.t], [P.u] ], [ [P.g] ], [ [P.t] ] ],
                couplings = {(0,2,1):C.R2GC_146_1,(0,0,2):C.R2GC_151_5,(0,1,0):C.R2GC_249_41})

V_64 = CTVertex(name = 'V_64',
                type = 'R2',
                particles = [ P.u__tilde__, P.u ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FF1 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_155_9})

V_65 = CTVertex(name = 'V_65',
                type = 'R2',
                particles = [ P.c__tilde__, P.c ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FF1 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_155_9})

V_66 = CTVertex(name = 'V_66',
                type = 'R2',
                particles = [ P.t__tilde__, P.t ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FF2, L.FF3 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_379_85,(0,1,0):C.R2GC_155_9})

V_67 = CTVertex(name = 'V_67',
                type = 'R2',
                particles = [ P.d__tilde__, P.d ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FF1 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_155_9})

V_68 = CTVertex(name = 'V_68',
                type = 'R2',
                particles = [ P.s__tilde__, P.s ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FF1 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_155_9})

V_69 = CTVertex(name = 'V_69',
                type = 'R2',
                particles = [ P.b__tilde__, P.b ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FF1 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_155_9})

V_70 = CTVertex(name = 'V_70',
                type = 'R2',
                particles = [ P.g, P.g, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.VVV1 ],
                loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                couplings = {(0,0,0):C.R2GC_254_50,(0,0,1):C.R2GC_254_51})

V_71 = CTVertex(name = 'V_71',
                type = 'R2',
                particles = [ P.g, P.g, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.VVS1 ],
                loop_particles = [ [ [P.t] ] ],
                couplings = {(0,0,0):C.R2GC_153_7})

V_72 = CTVertex(name = 'V_72',
                type = 'R2',
                particles = [ P.a, P.a, P.g, P.g ],
                color = [ 'Identity(3,4)' ],
                lorentz = [ L.VVVV10 ],
                loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                couplings = {(0,0,0):C.R2GC_250_42,(0,0,1):C.R2GC_250_43})

V_73 = CTVertex(name = 'V_73',
                type = 'R2',
                particles = [ P.a, P.g, P.g, P.Z ],
                color = [ 'Identity(2,3)' ],
                lorentz = [ L.VVVV10 ],
                loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                couplings = {(0,0,0):C.R2GC_255_52,(0,0,1):C.R2GC_255_53})

V_74 = CTVertex(name = 'V_74',
                type = 'R2',
                particles = [ P.g, P.g, P.Z, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.VVVV10 ],
                loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                couplings = {(0,0,0):C.R2GC_259_61,(0,0,1):C.R2GC_259_62})

V_75 = CTVertex(name = 'V_75',
                type = 'R2',
                particles = [ P.g, P.g, P.W__minus__, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.VVVV10 ],
                loop_particles = [ [ [P.b, P.t], [P.c, P.s], [P.d, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_260_63})

V_76 = CTVertex(name = 'V_76',
                type = 'R2',
                particles = [ P.a, P.g, P.g, P.g ],
                color = [ 'd(2,3,4)' ],
                lorentz = [ L.VVVV10 ],
                loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                couplings = {(0,0,0):C.R2GC_251_44,(0,0,1):C.R2GC_251_45})

V_77 = CTVertex(name = 'V_77',
                type = 'R2',
                particles = [ P.g, P.g, P.g, P.Z ],
                color = [ 'd(1,2,3)', 'f(1,2,3)' ],
                lorentz = [ L.VVVV1, L.VVVV10 ],
                loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                couplings = {(1,0,0):C.R2GC_257_56,(1,0,1):C.R2GC_257_57,(0,1,0):C.R2GC_256_54,(0,1,1):C.R2GC_256_55})

V_78 = CTVertex(name = 'V_78',
                type = 'R2',
                particles = [ P.g, P.g, P.Z, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.VVVT1 ],
                loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.u] ], [ [P.t] ] ],
                couplings = {(0,0,0):C.R2GC_258_58,(0,0,1):C.R2GC_258_59,(0,0,2):C.R2GC_258_60})

V_79 = CTVertex(name = 'V_79',
                type = 'UV',
                particles = [ P.g, P.g, P.g ],
                color = [ 'f(1,2,3)' ],
                lorentz = [ L.VVV2 ],
                loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ] ],
                couplings = {(0,0,0):C.UVGC_366_61,(0,0,1):C.UVGC_366_62,(0,0,2):C.UVGC_366_63,(0,0,3):C.UVGC_366_64})

V_80 = CTVertex(name = 'V_80',
                type = 'UV',
                particles = [ P.g, P.g, P.g, P.g ],
                color = [ 'd(-1,1,3)*d(-1,2,4)', 'd(-1,1,3)*f(-1,2,4)', 'd(-1,1,4)*d(-1,2,3)', 'd(-1,1,4)*f(-1,2,3)', 'd(-1,2,3)*f(-1,1,4)', 'd(-1,2,4)*f(-1,1,3)', 'f(-1,1,2)*f(-1,3,4)', 'f(-1,1,3)*f(-1,2,4)', 'f(-1,1,4)*f(-1,2,3)', 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                lorentz = [ L.VVVV10, L.VVVV2, L.VVVV3, L.VVVV5 ],
                loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ] ],
                couplings = {(2,1,1):C.UVGC_349_37,(2,1,2):C.UVGC_349_36,(0,1,1):C.UVGC_349_37,(0,1,2):C.UVGC_349_36,(4,1,1):C.UVGC_348_34,(4,1,2):C.UVGC_348_35,(3,1,1):C.UVGC_348_34,(3,1,2):C.UVGC_348_35,(8,1,1):C.UVGC_349_36,(8,1,2):C.UVGC_349_37,(7,1,0):C.UVGC_369_71,(7,1,1):C.UVGC_369_72,(7,1,2):C.UVGC_369_73,(7,1,3):C.UVGC_369_74,(6,1,0):C.UVGC_369_71,(6,1,1):C.UVGC_370_75,(6,1,2):C.UVGC_370_76,(6,1,3):C.UVGC_369_74,(5,1,1):C.UVGC_348_34,(5,1,2):C.UVGC_348_35,(1,1,1):C.UVGC_348_34,(1,1,2):C.UVGC_348_35,(11,0,1):C.UVGC_352_40,(11,0,2):C.UVGC_352_41,(10,0,1):C.UVGC_352_40,(10,0,2):C.UVGC_352_41,(9,0,1):C.UVGC_351_38,(9,0,2):C.UVGC_351_39,(2,2,1):C.UVGC_349_37,(2,2,2):C.UVGC_349_36,(0,2,1):C.UVGC_349_37,(0,2,2):C.UVGC_349_36,(6,2,0):C.UVGC_367_65,(6,2,1):C.UVGC_368_69,(6,2,2):C.UVGC_368_70,(6,2,3):C.UVGC_367_68,(4,2,1):C.UVGC_348_34,(4,2,2):C.UVGC_348_35,(3,2,1):C.UVGC_348_34,(3,2,2):C.UVGC_348_35,(8,2,0):C.UVGC_369_71,(8,2,1):C.UVGC_369_72,(8,2,2):C.UVGC_369_73,(8,2,3):C.UVGC_369_74,(5,2,1):C.UVGC_348_34,(5,2,2):C.UVGC_348_35,(1,2,1):C.UVGC_348_34,(1,2,2):C.UVGC_348_35,(7,2,1):C.UVGC_349_36,(7,2,2):C.UVGC_349_37,(2,3,1):C.UVGC_349_37,(2,3,2):C.UVGC_349_36,(0,3,1):C.UVGC_349_37,(0,3,2):C.UVGC_349_36,(4,3,1):C.UVGC_348_34,(4,3,2):C.UVGC_348_35,(3,3,1):C.UVGC_348_34,(3,3,2):C.UVGC_348_35,(8,3,0):C.UVGC_367_65,(8,3,1):C.UVGC_367_66,(8,3,2):C.UVGC_367_67,(8,3,3):C.UVGC_367_68,(7,3,0):C.UVGC_367_65,(7,3,1):C.UVGC_367_66,(7,3,2):C.UVGC_367_67,(7,3,3):C.UVGC_367_68,(5,3,1):C.UVGC_348_34,(5,3,2):C.UVGC_348_35,(1,3,1):C.UVGC_348_34,(1,3,2):C.UVGC_348_35})

V_81 = CTVertex(name = 'V_81',
                type = 'UV',
                particles = [ P.b__tilde__, P.t, P.G__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.UVGC_387_104,(0,0,2):C.UVGC_387_105,(0,0,1):C.UVGC_387_106})

V_82 = CTVertex(name = 'V_82',
                type = 'UV',
                particles = [ P.t__tilde__, P.t, P.G0 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS1 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.UVGC_388_107})

V_83 = CTVertex(name = 'V_83',
                type = 'UV',
                particles = [ P.t__tilde__, P.t, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.UVGC_389_108})

V_84 = CTVertex(name = 'V_84',
                type = 'UV',
                particles = [ P.g, P.g, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.VVT10, L.VVT4, L.VVT6, L.VVT7 ],
                loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ] ],
                couplings = {(0,3,1):C.UVGC_261_1,(0,0,2):C.UVGC_262_2,(0,2,0):C.UVGC_371_77,(0,2,3):C.UVGC_371_78,(0,1,0):C.UVGC_354_46,(0,1,3):C.UVGC_354_47})

V_85 = CTVertex(name = 'V_85',
                type = 'UV',
                particles = [ P.g, P.g, P.g, P.Y2 ],
                color = [ 'f(1,2,3)' ],
                lorentz = [ L.VVVT5 ],
                loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ] ],
                couplings = {(0,0,0):C.UVGC_372_79,(0,0,1):C.UVGC_372_80,(0,0,2):C.UVGC_372_81,(0,0,3):C.UVGC_372_82})

V_86 = CTVertex(name = 'V_86',
                type = 'UV',
                particles = [ P.t__tilde__, P.t, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFT10, L.FFT11, L.FFT13, L.FFT15, L.FFT5, L.FFT6, L.FFT7 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,3,0):C.UVGC_376_86,(0,2,0):C.UVGC_266_6,(0,1,0):C.UVGC_318_21,(0,0,0):C.UVGC_321_24,(0,4,0):C.UVGC_360_56,(0,6,0):C.UVGC_326_27,(0,5,0):C.UVGC_364_59})

V_87 = CTVertex(name = 'V_87',
                type = 'UV',
                particles = [ P.t__tilde__, P.b, P.G__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS5 ],
                loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.UVGC_386_101,(0,0,2):C.UVGC_386_102,(0,0,1):C.UVGC_386_103})

V_88 = CTVertex(name = 'V_88',
                type = 'UV',
                particles = [ P.b__tilde__, P.b, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFT16, L.FFT18 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,1,0):C.UVGC_266_6,(0,0,0):C.UVGC_269_9})

V_89 = CTVertex(name = 'V_89',
                type = 'UV',
                particles = [ P.u__tilde__, P.u, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFT16, L.FFT18 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,1,0):C.UVGC_266_6,(0,0,0):C.UVGC_269_9})

V_90 = CTVertex(name = 'V_90',
                type = 'UV',
                particles = [ P.d__tilde__, P.d, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFT16, L.FFT18 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,1,0):C.UVGC_266_6,(0,0,0):C.UVGC_269_9})

V_91 = CTVertex(name = 'V_91',
                type = 'UV',
                particles = [ P.c__tilde__, P.c, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFT16, L.FFT18 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,1,0):C.UVGC_266_6,(0,0,0):C.UVGC_269_9})

V_92 = CTVertex(name = 'V_92',
                type = 'UV',
                particles = [ P.s__tilde__, P.s, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFT16, L.FFT18 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,1,0):C.UVGC_266_6,(0,0,0):C.UVGC_269_9})

V_93 = CTVertex(name = 'V_93',
                type = 'UV',
                particles = [ P.t__tilde__, P.t, P.a, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT11, L.FFVT13, L.FFVT25 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,2,0):C.UVGC_377_87,(0,0,0):C.UVGC_280_17,(0,1,0):C.UVGC_319_22})

V_94 = CTVertex(name = 'V_94',
                type = 'UV',
                particles = [ P.t__tilde__, P.t, P.Z, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT1, L.FFVT10, L.FFVT27, L.FFVT30, L.FFVT32, L.FFVT6 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.UVGC_383_98,(0,2,0):C.UVGC_385_100,(0,1,0):C.UVGC_285_19,(0,5,0):C.UVGC_323_25,(0,4,0):C.UVGC_274_14,(0,3,0):C.UVGC_325_26})

V_95 = CTVertex(name = 'V_95',
                type = 'UV',
                particles = [ P.b__tilde__, P.b, P.a, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT11, L.FFVT33 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,0,0):C.UVGC_267_7,(0,1,0):C.UVGC_270_10})

V_96 = CTVertex(name = 'V_96',
                type = 'UV',
                particles = [ P.b__tilde__, P.b, P.Z, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT10, L.FFVT19, L.FFVT23, L.FFVT4 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,0,0):C.UVGC_272_12,(0,3,0):C.UVGC_273_13,(0,1,0):C.UVGC_274_14,(0,2,0):C.UVGC_275_15})

V_97 = CTVertex(name = 'V_97',
                type = 'UV',
                particles = [ P.u__tilde__, P.u, P.a, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT11, L.FFVT33 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.UVGC_280_17,(0,1,0):C.UVGC_283_18})

V_98 = CTVertex(name = 'V_98',
                type = 'UV',
                particles = [ P.d__tilde__, P.d, P.a, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT11, L.FFVT33 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,0,0):C.UVGC_267_7,(0,1,0):C.UVGC_270_10})

V_99 = CTVertex(name = 'V_99',
                type = 'UV',
                particles = [ P.u__tilde__, P.u, P.Z, P.Y2 ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFVT10, L.FFVT28, L.FFVT32, L.FFVT4 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.UVGC_285_19,(0,3,0):C.UVGC_286_20,(0,2,0):C.UVGC_274_14,(0,1,0):C.UVGC_275_15})

V_100 = CTVertex(name = 'V_100',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.Z, P.Y2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFVT10, L.FFVT19, L.FFVT23, L.FFVT4 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_272_12,(0,3,0):C.UVGC_273_13,(0,1,0):C.UVGC_274_14,(0,2,0):C.UVGC_275_15})

V_101 = CTVertex(name = 'V_101',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.a, P.Y2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFVT11, L.FFVT33 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_280_17,(0,1,0):C.UVGC_283_18})

V_102 = CTVertex(name = 'V_102',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.a, P.Y2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFVT11, L.FFVT33 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_267_7,(0,1,0):C.UVGC_270_10})

V_103 = CTVertex(name = 'V_103',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.Z, P.Y2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFVT10, L.FFVT28, L.FFVT32, L.FFVT4 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_285_19,(0,3,0):C.UVGC_286_20,(0,2,0):C.UVGC_274_14,(0,1,0):C.UVGC_275_15})

V_104 = CTVertex(name = 'V_104',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.Z, P.Y2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFVT10, L.FFVT19, L.FFVT23, L.FFVT4 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_272_12,(0,3,0):C.UVGC_273_13,(0,1,0):C.UVGC_274_14,(0,2,0):C.UVGC_275_15})

V_105 = CTVertex(name = 'V_105',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u, P.g, P.Y2 ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFVT15, L.FFVT24, L.FFVT25 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.u] ], [ [P.t] ] ],
                 couplings = {(0,2,0):C.UVGC_355_48,(0,2,1):C.UVGC_355_49,(0,2,2):C.UVGC_355_50,(0,2,4):C.UVGC_355_51,(0,0,3):C.UVGC_268_8,(0,1,3):C.UVGC_271_11})

V_106 = CTVertex(name = 'V_106',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.g, P.Y2 ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFVT15, L.FFVT24, L.FFVT25 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.d, P.g] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ] ],
                 couplings = {(0,2,0):C.UVGC_355_48,(0,2,2):C.UVGC_355_49,(0,2,3):C.UVGC_355_50,(0,2,4):C.UVGC_355_51,(0,0,1):C.UVGC_268_8,(0,1,1):C.UVGC_271_11})

V_107 = CTVertex(name = 'V_107',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.g, P.Y2 ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFVT15, L.FFVT24, L.FFVT25 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.c, P.g] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ] ],
                 couplings = {(0,2,0):C.UVGC_355_48,(0,2,2):C.UVGC_355_49,(0,2,3):C.UVGC_355_50,(0,2,4):C.UVGC_355_51,(0,0,1):C.UVGC_268_8,(0,1,1):C.UVGC_271_11})

V_108 = CTVertex(name = 'V_108',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.g, P.Y2 ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFVT15, L.FFVT24, L.FFVT25 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.s] ], [ [P.t] ] ],
                 couplings = {(0,2,0):C.UVGC_355_48,(0,2,1):C.UVGC_355_49,(0,2,2):C.UVGC_355_50,(0,2,4):C.UVGC_355_51,(0,0,3):C.UVGC_268_8,(0,1,3):C.UVGC_271_11})

V_109 = CTVertex(name = 'V_109',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.g, P.Y2 ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFVT15, L.FFVT24, L.FFVT25 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.b, P.g] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ] ],
                 couplings = {(0,2,0):C.UVGC_355_48,(0,2,2):C.UVGC_355_49,(0,2,3):C.UVGC_355_50,(0,2,4):C.UVGC_355_51,(0,0,1):C.UVGC_268_8,(0,1,1):C.UVGC_271_11})

V_110 = CTVertex(name = 'V_110',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.g, P.Y2 ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFVT15, L.FFVT17, L.FFVT25 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.t] ], [ [P.t] ] ],
                 couplings = {(0,2,0):C.UVGC_378_88,(0,2,1):C.UVGC_378_89,(0,2,2):C.UVGC_378_90,(0,2,4):C.UVGC_378_91,(0,2,3):C.UVGC_378_92,(0,0,3):C.UVGC_268_8,(0,1,3):C.UVGC_320_23})

V_111 = CTVertex(name = 'V_111',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.u, P.W__minus__, P.Y2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFVT1, L.FFVT10, L.FFVT6 ],
                 loop_particles = [ [ [P.d, P.g], [P.g, P.u] ], [ [P.d, P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_357_55,(0,1,1):C.UVGC_340_28,(0,2,1):C.UVGC_341_29})

V_112 = CTVertex(name = 'V_112',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.d, P.W__plus__, P.Y2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFVT1, L.FFVT10, L.FFVT6 ],
                 loop_particles = [ [ [P.d, P.g], [P.g, P.u] ], [ [P.d, P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_357_55,(0,1,1):C.UVGC_340_28,(0,2,1):C.UVGC_341_29})

V_113 = CTVertex(name = 'V_113',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.c, P.W__minus__, P.Y2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFVT1, L.FFVT10, L.FFVT6 ],
                 loop_particles = [ [ [P.c, P.g], [P.g, P.s] ], [ [P.c, P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_357_55,(0,1,1):C.UVGC_340_28,(0,2,1):C.UVGC_341_29})

V_114 = CTVertex(name = 'V_114',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.s, P.W__plus__, P.Y2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFVT1, L.FFVT10, L.FFVT6 ],
                 loop_particles = [ [ [P.c, P.g], [P.g, P.s] ], [ [P.c, P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_357_55,(0,1,1):C.UVGC_340_28,(0,2,1):C.UVGC_341_29})

V_115 = CTVertex(name = 'V_115',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.b, P.W__plus__, P.Y2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFVT1, L.FFVT10, L.FFVT3, L.FFVT8 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_382_96,(0,0,2):C.UVGC_382_97,(0,1,1):C.UVGC_340_28,(0,2,1):C.UVGC_343_30,(0,3,1):C.UVGC_344_31})

V_116 = CTVertex(name = 'V_116',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.t, P.W__minus__, P.Y2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFVT1, L.FFVT10, L.FFVT3, L.FFVT8 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_382_96,(0,0,2):C.UVGC_382_97,(0,1,1):C.UVGC_340_28,(0,3,1):C.UVGC_343_30,(0,2,1):C.UVGC_344_31})

V_117 = CTVertex(name = 'V_117',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV4 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_277_16})

V_118 = CTVertex(name = 'V_118',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV6 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_277_16,(0,1,0):C.UVGC_374_84})

V_119 = CTVertex(name = 'V_119',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV4 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_277_16})

V_120 = CTVertex(name = 'V_120',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV4 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_264_4})

V_121 = CTVertex(name = 'V_121',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV4 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_264_4})

V_122 = CTVertex(name = 'V_122',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV4 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_264_4})

V_123 = CTVertex(name = 'V_123',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV5, L.FFV6 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.c, P.g] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ] ],
                 couplings = {(0,0,1):C.UVGC_265_5,(0,1,0):C.UVGC_353_42,(0,1,2):C.UVGC_353_43,(0,1,3):C.UVGC_353_44,(0,1,4):C.UVGC_353_45})

V_124 = CTVertex(name = 'V_124',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV6 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.t] ], [ [P.t] ] ],
                 couplings = {(0,0,3):C.UVGC_265_5,(0,1,0):C.UVGC_353_42,(0,1,1):C.UVGC_353_43,(0,1,2):C.UVGC_353_44,(0,1,4):C.UVGC_353_45,(0,1,3):C.UVGC_375_85})

V_125 = CTVertex(name = 'V_125',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV5, L.FFV6 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.u] ], [ [P.t] ] ],
                 couplings = {(0,0,3):C.UVGC_265_5,(0,1,0):C.UVGC_353_42,(0,1,1):C.UVGC_353_43,(0,1,2):C.UVGC_353_44,(0,1,4):C.UVGC_353_45})

V_126 = CTVertex(name = 'V_126',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV5, L.FFV6 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.b, P.g] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ] ],
                 couplings = {(0,0,1):C.UVGC_265_5,(0,1,0):C.UVGC_353_42,(0,1,2):C.UVGC_353_43,(0,1,3):C.UVGC_353_44,(0,1,4):C.UVGC_353_45})

V_127 = CTVertex(name = 'V_127',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV5, L.FFV6 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.d, P.g] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ] ],
                 couplings = {(0,0,1):C.UVGC_265_5,(0,1,0):C.UVGC_353_42,(0,1,2):C.UVGC_353_43,(0,1,3):C.UVGC_353_44,(0,1,4):C.UVGC_353_45})

V_128 = CTVertex(name = 'V_128',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV5, L.FFV6 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.s] ], [ [P.t] ] ],
                 couplings = {(0,0,3):C.UVGC_265_5,(0,1,0):C.UVGC_353_42,(0,1,1):C.UVGC_353_43,(0,1,2):C.UVGC_353_44,(0,1,4):C.UVGC_353_45})

V_129 = CTVertex(name = 'V_129',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.c, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.c, P.g], [P.g, P.s] ], [ [P.c, P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_362_57,(0,0,1):C.UVGC_362_58})

V_130 = CTVertex(name = 'V_130',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.t, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_362_57,(0,0,2):C.UVGC_380_94,(0,0,1):C.UVGC_362_58})

V_131 = CTVertex(name = 'V_131',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.u, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.d, P.g], [P.g, P.u] ], [ [P.d, P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_362_57,(0,0,1):C.UVGC_362_58})

V_132 = CTVertex(name = 'V_132',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.b, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_362_57,(0,0,2):C.UVGC_380_94,(0,0,1):C.UVGC_362_58})

V_133 = CTVertex(name = 'V_133',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.d, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.d, P.g], [P.g, P.u] ], [ [P.d, P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_362_57,(0,0,1):C.UVGC_362_58})

V_134 = CTVertex(name = 'V_134',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.s, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2 ],
                 loop_particles = [ [ [P.c, P.g], [P.g, P.s] ], [ [P.c, P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_362_57,(0,0,1):C.UVGC_362_58})

V_135 = CTVertex(name = 'V_135',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV2, L.FFV8 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_381_95,(0,1,0):C.UVGC_384_99})

V_136 = CTVertex(name = 'V_136',
                 type = 'UV',
                 particles = [ P.g, P.g ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VV1, L.VV5 ],
                 loop_particles = [ [ [P.g] ], [ [P.ghG] ], [ [P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_347_32,(0,0,1):C.UVGC_347_33,(0,1,2):C.UVGC_365_60})

V_137 = CTVertex(name = 'V_137',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF4 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_263_3})

V_138 = CTVertex(name = 'V_138',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF4 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_263_3})

V_139 = CTVertex(name = 'V_139',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF2, L.FF3 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_379_93,(0,1,0):C.UVGC_373_83})

V_140 = CTVertex(name = 'V_140',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF4 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_263_3})

V_141 = CTVertex(name = 'V_141',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF4 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_263_3})

V_142 = CTVertex(name = 'V_142',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF4 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_263_3})

V_143 = CTVertex(name = 'V_143',
                 type = 'UV',
                 particles = [ P.g, P.g, P.Z, P.Y2 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVT2 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.u] ], [ [P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_356_52,(0,0,1):C.UVGC_356_53,(0,0,2):C.UVGC_356_54})

